using System.Collections.Generic;

public class CardStack
{
    private LinkedList<Card> cards = new LinkedList<Card>();

    public void Add(Card card) => cards.AddLast(card);
    
    public Card DrawTop()
    {
        if (cards.Count == 0)
            throw new System.InvalidOperationException("No hay cartas en la pila para dibujar.");
        
        var card = cards.First.Value;
        cards.RemoveFirst();
        return card;
    }
    
    public bool TryDrawTop(out Card card)
    {
        card = null;
        if (cards.Count == 0)
            return false;
        
        card = cards.First.Value;
        cards.RemoveFirst();
        return true;
    }

    public int Count => cards.Count;
    public IEnumerable<Card> Cards => cards;
}
