using UnityEngine;

public class CardView : MonoBehaviour
{
    public Card Model;

    public void SetCard(Card card)
    {
        Model = card;
        UpdateVisual();
    }

    void UpdateVisual() { }
}
