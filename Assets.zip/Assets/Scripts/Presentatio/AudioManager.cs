using UnityEngine;

public class AudioManager : MonoBehaviour
{
    public void PlayCardSound() { }
    public void PlayCaptureSound() { }
}
