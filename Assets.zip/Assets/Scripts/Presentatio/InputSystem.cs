using UnityEngine;

public class InputSystem : MonoBehaviour
{
    public delegate void CardSelected(CardView card);
    public event CardSelected OnCardSelected;
}
