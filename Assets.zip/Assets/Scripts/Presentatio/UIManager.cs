using UnityEngine;

public class UIManager : MonoBehaviour
{
    public void UpdateHand(Player player) { }
    public void UpdateTable(CardStack table) { }
}
