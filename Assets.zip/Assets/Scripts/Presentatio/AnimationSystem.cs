using UnityEngine;

public class AnimationSystem : MonoBehaviour
{
    public void MoveCard(
        CardView card,
        Transform target)
    {
        // DOTween o Lerp
    }
}
