public class MatchSystem
{
    public bool CanCapture(Card handCard, Card tableCard)
    {
        return handCard.Value == tableCard.Value;
    }
}
