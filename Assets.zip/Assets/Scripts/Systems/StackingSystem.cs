
using System.Collections.Generic;

public class StackingSystem
{
    public ComplexNumber Stack(IEnumerable<Card> cards)
    {
        ComplexNumber result = null;

        foreach (var card in cards)
        {
            result = result == null
                ? card.Complex
                : result.Multiply(card.Complex);
        }

        return result;
    }
}
