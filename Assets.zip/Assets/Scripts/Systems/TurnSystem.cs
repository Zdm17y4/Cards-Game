public class TurnSystem
{
    private MatchState state;

    public TurnSystem(MatchState state)
    {
        this.state = state;
    }

    public Player CurrentPlayer =>
        state.Players[state.CurrentTurn];

    public void EndTurn()
    {
        state.CurrentTurn =
            (state.CurrentTurn + 1) % state.Players.Count;
    }
}
