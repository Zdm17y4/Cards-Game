public class GameManager
{
    public MatchState State;
    public TurnSystem TurnSystem;
    public MatchSystem MatchSystem;
    public StackingSystem StackingSystem;

    public void StartGame() { }
    public void EndGame() { }
}
