public enum CardSuit
{
    Cartesian,
    Polar,
    Graphic,
    Matrix,
    ExpMatrix
}
