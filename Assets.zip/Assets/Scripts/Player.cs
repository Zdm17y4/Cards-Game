public class Player
{
    public int Id;
    public CardStack Hand = new CardStack();
    public CardStack ScorePile = new CardStack();

    public Player(int id)
    {
        Id = id;
    }
}
