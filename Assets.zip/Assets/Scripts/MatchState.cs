using System.Collections.Generic;

public class MatchState
{
    public CardStack Table = new CardStack();
    public List<Player> Players = new List<Player>();
    public int CurrentTurn;
}
